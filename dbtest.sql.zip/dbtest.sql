-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 14, 2015 at 02:10 PM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `dbtest`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(5) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`user_id`, `username`, `email`, `password`) VALUES 
(1, 'MUSSA', 'ishimwe@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(2, 'JOSEPH', 'joseph@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e'),
(3, 'joseph', 'jose@gmail.com', '25f9e794323b453885f5181f1b624d0b'),
(4, 'allo', 'p@gmail.com', '1c395a8dce135849bd73c6dba3b54809'),
(5, 'Fabrice', 'fabrice@gmail.com', '25f9e794323b453885f5181f1b624d0b'),
(6, 'JOSEPH', 'ishimwej58@gmail.com', 'f2ae894c4be98e3f6fd9c0896f99564c');
